/**
 * @file student.h
 * @author McMaster University
 * @date 2022-04-09
 * @brief header file for student operations
 */

/**
 * student type which stores a student with fields first_name, last_name, and a 11 character id,list of grades, integer num_grades
 *
 */
typedef struct _student 
{ 
  char first_name[50]; /**< student's first name*/
  char last_name[50]; /**< student's last name*/
  char id[11]; /**< 11 character student ID*/
  double *grades; /**< dynamically allocated list of grades*/
  int num_grades; /**< number of grades in the grades list*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
