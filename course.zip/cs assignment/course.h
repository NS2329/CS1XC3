/**
 * @file course.h
 * @author McMaster University
 * @date 2022-04-09
 * @brief header file declaring the course operations
 */
#include "student.h"
#include <stdbool.h>

/**
 * course type that stores a course with  code, fields name, students and total_students
 *
 */
typedef struct _course 
{
  char name[100]; /**< name of the course*/
  char code[10]; /**< course code*/
  Student *students; /**< dynamically allocated list of students enrolled in the course*/
  int total_students; /**< the number of students enrolled in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


