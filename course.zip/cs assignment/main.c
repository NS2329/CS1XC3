/**
 * @file main.c
 * @author McMaster University
 * @date 2022-04-09
 * @brief file that you run
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * Main function of the program is to create a MATH101 course and enroll 20 students randomly,
 * while printing information about the students as well
 *
 * @return 0
 */
int main()
{
  // seed the random number generator
  srand((unsigned) time(NULL));

  // allocate course MATH101
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // enroll 20 students randomly random 
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));

  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}